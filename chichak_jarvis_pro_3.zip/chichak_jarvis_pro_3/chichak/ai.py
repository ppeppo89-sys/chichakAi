import requests
from config import CFG
from chichak.logging_utils import log

SYSTEM = (
    "Ти си Чичак, български гласов асистент за Android. "
    "Говориш естествено на български, на кирилица, кратко и ясно. "
    "Не твърдиш, че си изпълнил действие, ако то не е потвърдено от системата. "
    "Не искаш и не разкриваш API ключове, пароли или лични данни. "
    "За опасни или необратими действия изискваш изрично потвърждение."
)

class AIEngine:
    def __init__(self, memory):
        self.memory = memory

    def ask(self, prompt):
        history = self.memory.recent()
        facts = self.memory.facts()
        context = "\n".join(f"{r}: {c}" for r, c in history[-20:])
        fact_text = "\n".join(f"{k}: {v}" for k, v in facts)
        user_text = f"Запомнени факти:\n{fact_text}\n\nПоследен разговор:\n{context}\n\nПотребител: {prompt}"
        try:
            if CFG.provider == "gemini":
                answer = self._gemini(user_text)
            elif CFG.provider == "openai":
                answer = self._openai(user_text)
            else:
                raise RuntimeError("Непознат AI_PROVIDER. Използвай gemini или openai.")
            self.memory.add_turn("user", prompt)
            self.memory.add_turn("assistant", answer)
            return answer
        except Exception as exc:
            log.exception("AI заявката не успя: %s", exc)
            return None

    def _gemini(self, text):
        if not CFG.gemini_key:
            raise RuntimeError("Липсва GEMINI_API_KEY в .env")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{CFG.gemini_model}:generateContent"
        payload = {"system_instruction":{"parts":[{"text":SYSTEM}]},
                   "contents":[{"role":"user","parts":[{"text":text}]}],
                   "generationConfig":{"temperature":0.65,"maxOutputTokens":700}}
        r = requests.post(url, params={"key":CFG.gemini_key}, json=payload, timeout=35)
        r.raise_for_status()
        data = r.json()
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()

    def _openai(self, text):
        if not CFG.openai_key:
            raise RuntimeError("Липсва OPENAI_API_KEY в .env")
        url = CFG.openai_base_url + "/chat/completions"
        payload = {"model":CFG.openai_model,
                   "messages":[{"role":"system","content":SYSTEM},{"role":"user","content":text}],
                   "temperature":0.65,"max_tokens":700}
        r = requests.post(url, headers={"Authorization":f"Bearer {CFG.openai_key}"},
                          json=payload, timeout=35)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"].strip()
