import os, subprocess, urllib.parse, time
from chichak.logging_utils import log
from config import DATA_DIR

def run(args, timeout=15):
    try:
        return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, timeout=timeout)
    except Exception as e:
        log.warning("Android команда %s: %s", args[0], e)
        return None

def open_url(url):
    return run(["am","start","-a","android.intent.action.VIEW","-d",url])

def open_app(package):
    return run(["monkey","-p",package,"-c","android.intent.category.LAUNCHER","1"])

def battery():
    r = run(["termux-battery-status"])
    if not r or r.returncode:
        return "Не мога да прочета батерията. Провери Termux:API."
    import json
    d = json.loads(r.stdout)
    return f"Батерията е {d.get('percentage','?')} процента. Температура: {d.get('temperature','?')} градуса."

def take_photo():
    path = os.path.join(DATA_DIR, "camera.jpg")
    r = run(["termux-camera-photo","-c","0",path], timeout=30)
    if r and r.returncode == 0 and os.path.exists(path):
        run(["termux-open",path])
        return f"Снимката е записана: {path}"
    return "Не успях да направя снимка. Провери разрешението за камера."

def torch(enabled):
    r = run(["termux-torch", "on" if enabled else "off"])
    return bool(r and r.returncode == 0)

def vibrate(ms=300):
    return run(["termux-vibrate","-d",str(ms)])

def volume(level):
    return run(["termux-volume","music",str(max(0,min(15,int(level))))])

def search_web(query):
    open_url("https://www.google.com/search?q=" + urllib.parse.quote(query))
    return f"Отварям търсене за {query}."

def search_music(query, service="youtube"):
    if service == "spotify":
        url = "https://open.spotify.com/search/" + urllib.parse.quote(query)
    else:
        url = "https://music.youtube.com/search?q=" + urllib.parse.quote(query)
    open_url(url)
    return f"Търся {query} в {service}."

def call_number(number):
    return run(["termux-telephony-call", number], timeout=10)

def send_sms(number, message):
    return run(["termux-sms-send","-n",number,message], timeout=15)
