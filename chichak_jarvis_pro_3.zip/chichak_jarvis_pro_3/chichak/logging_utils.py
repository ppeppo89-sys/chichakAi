import logging, os
from logging.handlers import RotatingFileHandler
from config import DATA_DIR

def setup_logging():
    os.makedirs(DATA_DIR, exist_ok=True)
    logger = logging.getLogger("chichak")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = RotatingFileHandler(os.path.join(DATA_DIR, "chichak.log"),
                                      maxBytes=1_000_000, backupCount=3,
                                      encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        logger.addHandler(handler)
        console = logging.StreamHandler()
        console.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
        logger.addHandler(console)
    return logger

log = setup_logging()
