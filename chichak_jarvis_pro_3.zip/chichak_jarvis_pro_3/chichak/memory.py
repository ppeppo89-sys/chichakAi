import sqlite3
from datetime import datetime
from config import DB_PATH, CFG

class Memory:
    def __init__(self):
        self.db = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS turns(
            id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL,
            content TEXT NOT NULL, created_at TEXT NOT NULL)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS facts(
            key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)""")
        self.db.commit()

    def add_turn(self, role, content):
        self.db.execute("INSERT INTO turns(role,content,created_at) VALUES(?,?,?)",
                        (role, content[:8000], datetime.now().isoformat(timespec="seconds")))
        self.db.commit()

    def recent(self, limit=None):
        limit = limit or CFG.max_memory_turns * 2
        rows = self.db.execute("SELECT role,content FROM turns ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return list(reversed(rows))

    def remember_fact(self, key, value):
        self.db.execute("INSERT INTO facts(key,value,updated_at) VALUES(?,?,?) "
                        "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                        (key[:100], value[:2000], datetime.now().isoformat(timespec="seconds")))
        self.db.commit()

    def facts(self):
        return self.db.execute("SELECT key,value FROM facts ORDER BY updated_at DESC LIMIT 100").fetchall()

    def close(self):
        self.db.close()
