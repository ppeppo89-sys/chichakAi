import threading, time, sqlite3
from datetime import datetime
from config import DB_PATH
from chichak.logging_utils import log

class Reminders:
    def __init__(self, notify):
        self.notify = notify
        self.db = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS reminders(
            id INTEGER PRIMARY KEY AUTOINCREMENT, message TEXT NOT NULL,
            due TEXT NOT NULL, done INTEGER DEFAULT 0)""")
        self.db.commit()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def add(self, message, due):
        # due: ISO локално време YYYY-MM-DD HH:MM
        datetime.strptime(due, "%Y-%m-%d %H:%M")
        self.db.execute("INSERT INTO reminders(message,due) VALUES(?,?)",(message,due))
        self.db.commit()

    def list_pending(self):
        return self.db.execute("SELECT id,message,due FROM reminders WHERE done=0 ORDER BY due").fetchall()

    def _worker(self):
        while not self.stop_event.is_set():
            try:
                now = datetime.now().strftime("%Y-%m-%d %H:%M")
                rows = self.db.execute("SELECT id,message FROM reminders WHERE done=0 AND due<=?",(now,)).fetchall()
                for rid, msg in rows:
                    self.db.execute("UPDATE reminders SET done=1 WHERE id=?",(rid,))
                    self.db.commit()
                    self.notify("Напомняне: " + msg)
            except Exception as e:
                log.warning("Reminder worker: %s", e)
            self.stop_event.wait(15)

    def close(self):
        self.stop_event.set()
        self.db.close()
