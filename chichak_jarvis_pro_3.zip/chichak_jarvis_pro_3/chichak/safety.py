import re

def valid_phone(value):
    value = value.strip().replace(" ", "").replace("-", "")
    return bool(re.fullmatch(r"\+?[0-9]{7,15}", value))

def confirm(prompt, voice):
    voice.speak(prompt + " Кажи да или не.")
    answer = voice.listen()
    return answer in {"да","давай","потвърждавам","потвърди"}

def safe_contact_lookup(name, path="kontakti.txt"):
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                if "=" not in line:
                    continue
                person, number = line.strip().split("=",1)
                if name.lower() == person.strip().lower():
                    return person.strip(), number.strip()
    except FileNotFoundError:
        pass
    return None, None
