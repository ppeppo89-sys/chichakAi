import os, subprocess, time, tempfile
import speech_recognition as sr
from config import CFG, DATA_DIR
from chichak.logging_utils import log

def command(args, timeout=15):
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          text=True, timeout=timeout)

class Voice:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.recognizer.pause_threshold = 0.8
        self.recognizer.non_speaking_duration = 0.5

    def speak(self, text):
        if not text:
            return
        print(f"Чичак: {text}")
        mp3 = os.path.join(DATA_DIR, "speech.mp3")
        txt = os.path.join(DATA_DIR, "speech.txt")
        try:
            with open(txt, "w", encoding="utf-8") as f:
                f.write(text)
            subprocess.run(["edge-tts", "--voice", CFG.tts_voice, "--file", txt,
                            "--write-media", mp3], check=True, timeout=40)
            subprocess.run(["termux-media-player", "play", mp3],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
            # Изчакване приблизително според дължината; не блокира с дълги паузи.
            time.sleep(min(12, max(1.5, len(text) / 22)))
        except Exception as e:
            log.warning("TTS проблем: %s", e)

    def listen(self):
        wav = os.path.join(DATA_DIR, "listen.wav")
        try:
            subprocess.run(["termux-microphone-record", "-q"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
            if os.path.exists(wav):
                os.remove(wav)
            subprocess.run(["termux-microphone-record", "-f", wav, "-l",
                            str(CFG.record_seconds), "-e", "wav"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=CFG.record_seconds + 5)
            deadline = time.time() + CFG.record_seconds + 3
            while time.time() < deadline and not os.path.exists(wav):
                time.sleep(0.2)
            if not os.path.exists(wav) or os.path.getsize(wav) < 1000:
                return ""
            with sr.AudioFile(wav) as source:
                audio = self.recognizer.record(source)
            return self.recognizer.recognize_google(audio, language=CFG.stt_language).lower().strip()
        except sr.UnknownValueError:
            return ""
        except Exception as e:
            log.warning("Слушането не успя: %s", e)
            return ""
        finally:
            try:
                subprocess.run(["termux-microphone-record", "-q"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
            except Exception:
                pass
