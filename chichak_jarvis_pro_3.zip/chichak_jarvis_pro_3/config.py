from dataclasses import dataclass
from dotenv import load_dotenv
import os

load_dotenv()

@dataclass(frozen=True)
class Config:
    assistant_name: str = "Чичак"
    version: str = "3.0 PRO"
    provider: str = os.getenv("AI_PROVIDER", "gemini").lower()
    gemini_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    openai_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_base_url: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    tts_voice: str = os.getenv("TTS_VOICE", "bg-BG-BorislavNeural")
    stt_language: str = os.getenv("STT_LANGUAGE", "bg-BG")
    city: str = os.getenv("CITY", "София")
    record_seconds: int = max(3, min(20, int(os.getenv("RECORD_SECONDS", "8"))))
    max_memory_turns: int = max(5, min(100, int(os.getenv("MAX_MEMORY_TURNS", "30"))))

CFG = Config()
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "chichak.db")
