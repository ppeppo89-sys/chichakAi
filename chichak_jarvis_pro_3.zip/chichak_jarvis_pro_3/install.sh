#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg upgrade -y
pkg install -y python ffmpeg termux-api
python -m pip install --upgrade pip
pip install -r requirements.txt
mkdir -p data
if [ ! -f .env ]; then cp .env.example .env; fi
if [ ! -f kontakti.txt ]; then cp kontakti.txt.example kontakti.txt; fi
chmod 700 .
chmod 600 .env kontakti.txt 2>/dev/null || true
echo
echo "Инсталацията приключи."
echo "Редактирай .env и добави AI ключ. После стартирай: python main.py"
