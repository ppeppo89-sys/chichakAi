import os, re, urllib.parse
from datetime import datetime, timedelta
from config import CFG
from chichak.logging_utils import log
from chichak.voice import Voice
from chichak.memory import Memory
from chichak.ai import AIEngine
from chichak import android
from chichak.reminders import Reminders
from chichak.safety import valid_phone, confirm, safe_contact_lookup

APPS = {
    "youtube":"com.google.android.youtube", "ютюб":"com.google.android.youtube",
    "tiktok":"com.zhiliaoapp.musically", "тикток":"com.zhiliaoapp.musically",
    "instagram":"com.instagram.android", "инстаграм":"com.instagram.android",
    "facebook":"com.facebook.katana", "фейсбук":"com.facebook.katana",
    "whatsapp":"com.whatsapp", "уатсап":"com.whatsapp", "ватсап":"com.whatsapp",
    "telegram":"org.telegram.messenger", "телеграм":"org.telegram.messenger",
    "spotify":"com.spotify.music", "спотифай":"com.spotify.music",
}

class Chichak:
    def __init__(self):
        self.voice = Voice()
        self.memory = Memory()
        self.ai = AIEngine(self.memory)
        self.reminders = Reminders(self.voice.speak)
        self.pending_sms = None

    def reply(self, text):
        self.voice.speak(text)

    def handle(self, t):
        if not t:
            return
        log.info("Команда: %s", t)

        # Изходът е точна команда, за да не прихваща фрази като „спри фенера“.
        if t in {"изключи се","чао","излез от програмата","спри асистента"}:
            self.reply("Изключвам се. До скоро, Сър.")
            raise SystemExit

        if "колко е час" in t or t == "час":
            self.reply("Сега е " + datetime.now().strftime("%H:%M") + "."); return
        if "каква дата" in t or "кой ден сме" in t:
            self.reply("Днес е " + datetime.now().strftime("%d.%m.%Y") + "."); return
        if "батери" in t:
            self.reply(android.battery()); return
        if "включи фенер" in t or "пусни фенер" in t:
            self.reply("Фенерът е включен." if android.torch(True) else "Не успях да включа фенера."); return
        if "изключи фенер" in t or "спри фенер" in t:
            self.reply("Фенерът е изключен." if android.torch(False) else "Не успях да изключа фенера."); return
        if "усили звука" in t:
            android.volume(15); self.reply("Усилих звука."); return
        if "намали звука" in t or "по-тихо" in t:
            android.volume(3); self.reply("Намалих звука."); return
        if "снимай" in t or "направи снимка" in t:
            if confirm("Да направя снимка с камерата?", self.voice):
                self.reply(android.take_photo())
            else: self.reply("Отказах снимката.")
            return

        if t.startswith("отвори "):
            target = t.replace("отвори ","",1).strip()
            for alias, package in APPS.items():
                if target == alias:
                    result = android.open_app(package)
                    if not result or result.returncode != 0:
                        self.reply("Не успях да отворя приложението. Провери дали е инсталирано.")
                    else:
                        self.reply("Отварям " + target + ".")
                    return

        if any(x in t for x in ["пусни музика","пусни песен","намери песен","потърси музика"]):
            q = re.sub(r"^(пусни музика|пусни песен|намери песен|потърси музика)","",t).strip() or "българска музика"
            service = "spotify" if "spotify" in t or "спотифай" in t else "youtube"
            self.reply(android.search_music(q, service)); return

        if "търси в интернет" in t or t.startswith("потърси "):
            q = t.replace("търси в интернет","").replace("потърси","").strip()
            self.reply(android.search_web(q)); return

        if "обади се на " in t or "звънни на " in t:
            name = t.replace("обади се на ","").replace("звънни на ","").strip()
            person, number = safe_contact_lookup(name)
            if not number or not valid_phone(number):
                self.reply("Не намерих валиден номер за този контакт. Добави го в kontakti.txt като Име=номер.")
            elif confirm(f"Да се обадя ли на {person}?", self.voice):
                result = android.call_number(number)
                self.reply("Изпратих командата за обаждане." if result and result.returncode == 0 else "Не успях да стартирам обаждането.")
            else: self.reply("Няма да се обаждам.")
            return

        if t.startswith("изпрати съобщение до "):
            # Формат: изпрати съобщение до Иван текст здравей
            m = re.match(r"изпрати съобщение до (.+?) текст (.+)", t)
            if not m:
                self.reply("Кажи: изпрати съобщение до Иван текст Здравей.")
                return
            person, number = safe_contact_lookup(m.group(1).strip())
            message = m.group(2).strip()
            if not number or not valid_phone(number):
                self.reply("Не намерих валиден номер за този контакт."); return
            if confirm(f"Да изпратя SMS до {person} със следния текст: {message}?", self.voice):
                result = android.send_sms(number, message)
                self.reply("SMS командата е изпратена." if result and result.returncode == 0 else "Изпращането не успя.")
            else: self.reply("Съобщението не е изпратено.")
            return

        if "напомни ми" in t:
            # Пример: напомни ми след 10 минути да се обадя на Иван
            m = re.search(r"след (\d+) (минути|минута|часа|час) (.+)", t)
            if m:
                amount = int(m.group(1))
                delta = timedelta(hours=amount) if m.group(2).startswith("час") else timedelta(minutes=amount)
                due = (datetime.now()+delta).strftime("%Y-%m-%d %H:%M")
                self.reminders.add(m.group(3).strip(), due)
                self.reply(f"Записах напомняне за {due}.")
            else:
                self.reply("Кажи например: напомни ми след 10 минути да се обадя на Иван.")
            return

        if "покажи напомняния" in t:
            rows = self.reminders.list_pending()
            self.reply("Нямаш предстоящи напомняния." if not rows else
                       "Предстоящи: " + "; ".join(f"{msg}, {due}" for _,msg,due in rows[:8]))
            return

        if t.startswith("запомни че "):
            fact = t.replace("запомни че ","",1).strip()
            self.memory.remember_fact("лична бележка", fact)
            self.reply("Запомних го."); return

        if "какво помниш" in t:
            facts = self.memory.facts()
            self.reply("Помня: " + "; ".join(f"{k}: {v}" for k,v in facts[:10]) if facts else "Все още нямам запомнени факти.")
            return

        # Общ разговор и сложни намерения
        answer = self.ai.ask(t)
        self.reply(answer or "Не успях да получа отговор от AI. Провери интернет връзката и API настройките.")

    def run(self):
        self.reply(f"Здравей, Сър. Аз съм Чичак, версия {CFG.version}. Готов съм.")
        while True:
            try:
                print("Слушам...")
                text = self.voice.listen()
                if text:
                    print("Ти:", text)
                    self.handle(text)
            except SystemExit:
                break
            except KeyboardInterrupt:
                break
            except Exception as e:
                log.exception("Грешка в главния цикъл: %s", e)
                self.reply("Възникна проблем. Продължавам да работя.")
        self.reminders.close()
        self.memory.close()
        self.reply("Чичак приключи работа.")

if __name__ == "__main__":
    Chichak().run()
